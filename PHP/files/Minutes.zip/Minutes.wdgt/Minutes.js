/*
 Minutes.js
 
 Author: MIURA Kazki
 
 Copyright Nitram+Nunca. All rights reserved.
 http://nitram-nunca.com/

About "clock", "time", "count"
"clock" is displayed on top of the UI. It indicates time to alerm.
"time" is set by user with knob.
"count" is gap between clock and now.
Unit of "time" and "count" is second.

Correspondence table of radians and minutes
-(Math.PI / 2) : 0
0 : 15
Math.PI : 30
Math.PI * 3 : 90	...
*/


//--------------------------------------------------------------//
//			Constans
//--------------------------------------------------------------//

// TEST
var KNOB_TEST = false;
var RESET_TEST = false;
var RESET_START_TIME = 3;
var RESET_TARGET_TIME = 2700;

// Preference keys
var MinutesSkinKey;
var MinutesTimeKey;
var MinutesActionKey;
var MinutesAddonKey;
var MinutesClockKey;
var MinutesBeepURLKey;
var MinutesOpenFileNameKey;
var MinutesOpenFileIconNameKey;
var MinutesPlaylistKey;
var MinutesPlaylistKindKey;
var MinutesFadeKey;

// Actions
var MinutesPlayITunesAction = 0;
var MinutesStopITunesAction = 1;
var MinutesBeepAction = 2;
var MinutesOpenFileAction = 3;
var MinutesNumberOfActions = 4;

// Action images
var _actionImages = new Array();
_actionImages[MinutesPlayITunesAction] = new Image();
_actionImages[MinutesPlayITunesAction].src = "Images/actionPlayitunes.png";
_actionImages[MinutesStopITunesAction] = new Image();
_actionImages[MinutesStopITunesAction].src = "Images/actionQuititunes.png";
_actionImages[MinutesBeepAction] = new Image();
_actionImages[MinutesBeepAction].src = "Images/actionBeep.png";
_actionImages[MinutesOpenFileAction] = new Image();
_actionImages[MinutesOpenFileAction].src = "Images/actionOpenfile.png";

// Action tooltips
var _actionTooltips = new Array();
_actionTooltips[MinutesPlayITunesAction] = "Playback iTunes playlist";
_actionTooltips[MinutesStopITunesAction] = "Stop iTunes";
_actionTooltips[MinutesBeepAction] = "Beep";
_actionTooltips[MinutesOpenFileAction] = "Open a file";

// Action Setting Divs
var _actionSettingDivs = null;

// Addon images for repeat
var _repeatAddonImages = new Array();
_repeatAddonImages[0] = new Image(); _repeatAddonImages[0].src = "Images/addonDoNotRepeat.png";
_repeatAddonImages[1] = new Image(); _repeatAddonImages[1].src = "Images/addonRepeat.png";

// Addon images for sleep
var _sleepAddonImages = new Array();
_sleepAddonImages[0] = new Image(); _sleepAddonImages[0].src = "Images/addonDoNotSleep.png";
_sleepAddonImages[1] = new Image(); _sleepAddonImages[1].src = "Images/addonSleep.png";

// Skin button images
var _skinButtonImages;

// Image buffer
var _progressImage;
var _knobImage;

// Visibility
var _isVisible = false;

// Count Down Timer
var _countDownTimer = null;

// iTunes Fade Out
var _originalVolume = -1;
var _fadeOutDuration = 30000;	// ms
var _fadeOutCueTimer = null;
var _fadeOutTimer = null;

// Update Clock Timer
var _updateClockTimer = null;

// Flicker Animation
var _flickerAnimator = null;
var _flickerDuration = 2000;		// ms

// Time Sub Fade Animation
var _timeSubFadeAnimator = null;
var _timeSubDefaultFadeDuration = 1000;		// ms

// Reset Animation
var _resetAnimator = null;
var _resetStartingSeconds;


//--------------------------------------------------------------//
//			Util
//--------------------------------------------------------------//
 
 String.prototype.capitalizedString = function() {
	return (this.charAt(0).toUpperCase() + this.substr(1));
}


function getElementPosition(element)
{
	var x = 0, y = 0;
	do {
		x += element.offsetLeft ? element.offsetLeft : 0;
		y += element.offsetTop ? element.offsetTop : 0;
	} while (element = element.offsetParent);
	
	return Array(x, y);
}

function setElementPosition(element, x, y)
{
	// Get parent position
	var parentPosition;
	parentPosition = getElementPosition(element.offsetParent);
	
	// Set element position
	element.style.left = x - parentPosition[0] + "px";
	element.style.top = y - parentPosition[1] + "px";
}


function registerDefaultPreference(value, key)
{
	if (!widget.preferenceForKey(key)) {
		widget.setPreferenceForKey(value, key);
	}
}


//--------------------------------------------------------------//
//		Widget Handlers
//--------------------------------------------------------------//

function load()
{
	// Set up parts
	setupParts();
	
	// Initialize _actionSettingDivs
	_actionSettingDivs = new Array();
	_actionSettingDivs[MinutesPlayITunesAction] = document.getElementById("playITunesDiv");
	_actionSettingDivs[MinutesStopITunesAction] = document.getElementById("stopITunesDiv");
	_actionSettingDivs[MinutesBeepAction] = document.getElementById("beepDiv");
	_actionSettingDivs[MinutesOpenFileAction] = document.getElementById("openFileDiv");
	
	// Load skin button images
	var skins;
	var i;
	_skinButtonImages = new Array();
	skins = getSkinNames();
	for (i = 0; i < skins.length; i++) {
		var skin, capitalizedSkin;
		var offImage, onImage;
		skin = skins[i];
		capitalizedSkin = skin.capitalizedString();
		offImage = new Image();
		offImage.src = "Images/ap" + capitalizedSkin + ".png";
		onImage = new Image();
		onImage.src = "Images/ap" + capitalizedSkin + "Selected.png";
		_skinButtonImages[skin] = new Array(offImage, onImage);
	}
	
	// Initialize progress image and knob image
	_progressImage = new Image();
	_knobImage = new Image();
	
	// Define preference keys
	MinutesSkinKey = createInstancePreferenceKey("Skin");
	MinutesTimeKey = createInstancePreferenceKey("Time");
	MinutesActionKey = createInstancePreferenceKey("Action");
	MinutesAddonKey = createInstancePreferenceKey("Addon");
	MinutesClockKey = createInstancePreferenceKey("Clock");
	MinutesBeepURLKey = createInstancePreferenceKey("BeepURL");
	MinutesOpenFileNameKey = createInstancePreferenceKey("OpenFileName");
	MinutesOpenFileIconNameKey = createInstancePreferenceKey("OpenFileIconName");
	MinutesPlaylistKey = createInstancePreferenceKey("Playlist");
	MinutesPlaylistKindKey = createInstancePreferenceKey("PlaylistKind");
	MinutesFadeKey = createInstancePreferenceKey("Fade");
	
	// Register default preferenes
	registerDefaultPreference("wood", MinutesSkinKey);
	registerDefaultPreference(900 + "", MinutesTimeKey);
	registerDefaultPreference(MinutesBeepAction + "", MinutesActionKey);
	registerDefaultPreference("0", MinutesAddonKey);
	registerDefaultPreference("Beeps/Bell.aif", MinutesBeepURLKey);
	registerDefaultPreference("", MinutesOpenFileNameKey);
	registerDefaultPreference("", MinutesOpenFileIconNameKey);
	registerDefaultPreference("1", MinutesFadeKey);
	registerDefaultPreference("Music", MinutesPlaylistKindKey);
	
	// Apply user defaults
	setAction(getAction());
	setAddon(getAddon());
	setSkin(getSkin());
	setFade(getFade(), true);
	setBeep(getBeep(), true, false);
	setTime(getTime());
}


function remove()
{
	// Stop timers...
	// _countDownTimer
	if (_countDownTimer) {
		clearInterval(_countDownTimer);
		delete _countDownTimer;
		_countDownTimer = null;
	}
	// _fadeOutCueTimer
	if (_fadeOutCueTimer) {
		clearInterval(_fadeOutCueTimer);
		delete _fadeOutCueTimer;
		_fadeOutCueTimer = null;
	}
	// _fadeOutTimer
	if (_fadeOutTimer) {
		clearInterval(_fadeOutTimer);
		delete _fadeOutTimer;
		_fadeOutTimer = null;
	}
	// _updateClockTimer
	if (_updateClockTimer) {
		clearInterval(_updateClockTimer);
		delete _updateClockTimer;
		_updateClockTimer = null;
	}
	// _flickerAnimator
	if (_flickerAnimator) {
		_flickerAnimator.stop();
		delete _flickerAnimator;
		_flickerAnimator = null;
	}
	// _timeSubFadeAnimator
	if (_timeSubFadeAnimator) {
		_timeSubFadeAnimator.stop();
		delete _timeSubFadeAnimator;
		_timeSubFadeAnimator = null;
	}
	// _resetAnimator
	if (_resetAnimator) {
		_resetAnimator.stop();
		delete _resetAnimator;
		_resetAnimator = null;
	}
	
	// Remove preferences
	widget.setPreferenceForKey(null, MinutesSkinKey);
	widget.setPreferenceForKey(null, MinutesTimeKey);
	widget.setPreferenceForKey(null, MinutesActionKey);
	widget.setPreferenceForKey(null, MinutesAddonKey);
	widget.setPreferenceForKey(null, MinutesClockKey);
	widget.setPreferenceForKey(null, MinutesBeepURLKey);
	widget.setPreferenceForKey(null, MinutesOpenFileNameKey);
	widget.setPreferenceForKey(null, MinutesOpenFileIconNameKey);
	widget.setPreferenceForKey(null, MinutesPlaylistKey);
	widget.setPreferenceForKey(null, MinutesPlaylistKindKey);
	widget.setPreferenceForKey(null, MinutesFadeKey);
	
	// Remove instance preference folder
	if (Minutes) {
		Minutes.removeFile(getInstanceApplicationSupportDirectoryURL());
	}
}


function hide()
{
	_isVisible = false;
	
	// Start or Stop timer and animation
	if (isCountingDown()) {
		// Convert count down timer to invisible version
		startCountingDown();
	}
	if (_updateClockTimer) {
		clearInterval(_updateClockTimer);
		delete _updateClockTimer;
		_updateClockTimer = null;
	}
	if (_flickerAnimator) {
		_flickerAnimator.stop();
		delete _flickerAnimator;
		_flickerAnimator = null;
	}
	if (_timeSubFadeAnimator) {
		_timeSubFadeAnimator.stop();
		delete _timeSubFadeAnimator;
		_timeSubFadeAnimator = null;
	}
	if (_resetAnimator) {
		_resetAnimator.stop();
		delete _resetAnimator;
		_resetAnimator = null;
	}
}


function show()
{
	_isVisible = true;
	
	// Update time related UIs
	updateTimeRelatedUIs();
	
	// Start or Stop timer and animation
	if (isCountingDown()) {
		// Convert count down timer to visible version
		startCountingDown();
	}
	else {
		document.getElementById("timeMain").style.opacity = 1.0;
		document.getElementById("displayBackProgressImg").style.opacity = 0.0;
		startTimeSubFadeAnimation(0, 1);
		startUpdateClockTimer();
	}
}


function sync()
{
	setAction(getAction());
	setAddon(getAddon());
	setSkin(getSkin());
	setFade(getFade(), true);
	setBeep(getBeep(), true, false);
	setTime(getTime());
}


//--------------------------------------------------------------//
//		Accessors
//--------------------------------------------------------------//

function getBaseURL()
{
	// Not contains last '/'
	var baseURL;
	baseURL = location.href;
	baseURL = baseURL.substr(0, baseURL.lastIndexOf("/"));
	
	return baseURL;
}

function getInstanceApplicationSupportDirectoryURL()
{
	// Not contains last '/'
	
	if (Minutes) {
		var url;
		var appSupp;
		appSupp = Minutes.minutesApplicationSupportDirectoryURL();
		if (!appSupp.length) {
			return null;
		}
		url = appSupp + widget.identifier;
		return url;
	}
	
	return null;
}


function getSkinNames()
{
	return new Array(
		"wood",
		"plastic",
		"moss",
		"cloth");
}


function getSkin()
{
	return widget.preferenceForKey(MinutesSkinKey);
}


function setSkin(skin)
{
	// Get old skin
	var oldSkin;
	oldSkin = getSkin();
	
	// Update preference
	widget.setPreferenceForKey(skin + "", MinutesSkinKey);
	
	// Get capitalized skin
	var capitalizedSkin;
	capitalizedSkin = skin.capitalizedString();
	
	// Update skin buttons
	document.getElementById(oldSkin + "ButtonImg").src = _skinButtonImages[oldSkin][0].src;
	document.getElementById(skin + "ButtonImg").src = _skinButtonImages[skin][1].src;
	
	// Update base image
	document.getElementById("baseImg").src = "Images/base" + skin.capitalizedString() + ".png";
	
	// Update progress image and knob image
	_progressImage.src = "Images/baseProgress" + capitalizedSkin + ".png";
	_knobImage.src = "Images/knob" + capitalizedSkin + ".png";
	drawProgressImage(getCount());
	drawKnobImage(getCount());
	
	// Update texts' class
	document.getElementById("clock").className = skin;
	document.getElementById("timeSub").className = skin;
	document.getElementById("timeMain").className = skin;
}


function getTime()
{
	if (RESET_TEST) {
		if (isResetting()) {
			return RESET_TARGET_TIME;
		}
		else {
			return RESET_START_TIME;
		}
	}
	return parseInt(widget.preferenceForKey(MinutesTimeKey));
}


function setTime(proposedTime)
{
	// Check argument
	var time;
	time = Math.min(Math.max(proposedTime, 1 * 60), 999 * 60);
	
	// Update preference
	widget.setPreferenceForKey(time + "", MinutesTimeKey);
	
	// Update UI
	if (!isCountingDown()) {
		document.getElementById("timeMain").innerText = Math.floor(time / 60) + "'";
	}
	
	return time;
}


function getCount()
{
	// Filter
	if (!isCountingDown()) {
		return getTime();
	}
	
	// Calc count
	var count;
	var clock, now;
	clock = new Date(widget.preferenceForKey(MinutesClockKey));
	now = new Date();
	now.setMilliseconds(0);
	count = (clock.getTime() - now.getTime()) / 1000;
	
	return count;
}


function getAction()
{
	return parseInt(widget.preferenceForKey(MinutesActionKey));
}


function setAction(action)
{
	// Get old action
	var oldAction;
	oldAction = getAction();
	
	// Update preference
	widget.setPreferenceForKey(action + "", MinutesActionKey);
	
	// Update action image
	document.getElementById("actionImg").src = _actionImages[action].src;
	
	// Update action tooltip
	document.getElementById("actionControlRegion").title = _actionTooltips[action];
	
	// Update addon image and tooltip
	setAddon(getAddon());
	
	// Update setting UI
	_actionSettingDivs[oldAction].style.visibility = "hidden";
	_actionSettingDivs[action].style.visibility = "visible";
	document.getElementById("openFileControlRegion").style.display = (action == MinutesOpenFileAction) ? "block" : "none";
}


function getAddon()
{
	return parseInt(widget.preferenceForKey(MinutesAddonKey));
}


function setAddon(addon)
{
	// Update preference
	widget.setPreferenceForKey(addon + "", MinutesAddonKey);
	
	// Update addon image
	var src;
	var tooltip;
	if (getAction() == MinutesStopITunesAction) {
		src = _sleepAddonImages[addon].src;
		if (addon) {
			tooltip = "sleep ON";
		}
		else {
			tooltip = "sleep OFF";
		}
	}
	else {
		src = _repeatAddonImages[addon].src;
		if (addon) {
			tooltip = "repeat ON";
		}
		else {
			tooltip = "repeat OFF";
		}
	}
	document.getElementById("addonImg").src = src;
	document.getElementById("addonControlRegion").title = tooltip;
}


function getFade()
{
	return parseInt(widget.preferenceForKey(MinutesFadeKey));
}


function setFade(fade, needsDisplay)
{
	// Update preference
	widget.setPreferenceForKey(fade + "", MinutesFadeKey);
	
	// Update UI
	if (needsDisplay) {
		document.getElementById("fadeCheckboxButton").checked = fade ? true : false;
	}
}


function getBeep()
{
	return widget.preferenceForKey(MinutesBeepURLKey);
}


function setBeep(url, needsDisplay, needsPlay)
{
	// Get popup
	var popup;
	popup = document.getElementById("beepPopUp");
	
	// Select popup item
	if (needsDisplay) {
		popup.selectedIndex = 0;
		for (var i = 0; i < popup.options.length; i++) {
			var option;
			option = popup.options[i];
			if (option.value == url) {
				popup.selectedIndex = i;
				break;
			}
		}
	}
	
	// Get valid url
	url = popup.options[popup.selectedIndex].value;
	
	// Update preference
	widget.setPreferenceForKey(url, MinutesBeepURLKey);
	
	if (Minutes) {
		// Set beep
		url = getBaseURL() + "/" + url;
		Minutes.setBeep(url);
		
		if (needsPlay) {
			Minutes.beep(false);
		}
	}
}


//--------------------------------------------------------------//
//			Action
//--------------------------------------------------------------//

function playITunes()
{
	if (Minutes) {
		var kind;
		kind = widget.preferenceForKey(MinutesPlaylistKindKey);
		if (kind == "none") {
			var playlist;
			playlist = widget.preferenceForKey(MinutesPlaylistKey);
			Minutes.playPlaylist(playlist, false);
		}
		else {
			Minutes.playPlaylist(kind, true);
		}
	}
}


function stopITunes()
{
	if (Minutes && Minutes.isITunesLaunched()) {
		if (Minutes.isITunesLaunched) {
			// Stop iTunes
			Minutes.stop();
			
			// Restore volume
			Minutes.setVolume(_originalVolume);
			_originalVolume = -1;
		}
	}
}


function beep()
{
	if (Minutes) {
		// Check loop
		var loop;
		var popup;
		popup = document.getElementById("beepPopUp");
		loop = (popup.options[popup.selectedIndex].className == "loop");
		Minutes.beep(loop);
	}
}


function showMessage(message)
{
	if (Minutes) {
		Minutes.showMessage(message, getSkin());
	}
}


function openFile()
{
	if (Minutes) {
		var filename;
		filename = widget.preferenceForKey(MinutesOpenFileNameKey);
		if (filename && filename.length) {
			var url, appSupp;
			appSupp = getInstanceApplicationSupportDirectoryURL();
			url = appSupp + "/OpenFile/" + filename;
			Minutes.openFile(url);
		}
	}
}


//--------------------------------------------------------------//
//			Clock Radian
//--------------------------------------------------------------//

function getRadianOfSeconds(seconds)
{
	var radian;
	var hour = 3600;
	radian = -(Math.PI / 2);
	radian += (seconds / hour * Math.PI * 2);
	
	return radian;
}


function getSecondsOfRadian(radian)
{
	var seconds;
	seconds = 15 * 60;
	seconds += radian / Math.PI * (30 * 60);
	
	return seconds;
}


function getFirstRadianForPoint(x, y)
{
	// Calc center point
	var centerX, centerY;
	var canvas;
	canvas = document.getElementById("knobCanvas");
	centerX = canvas.style.left + canvas.width / 2;
	centerY = canvas.style.top + canvas.height / 2;
	
	// Calc radian
	var radian;
	radian = -(Math.PI / 2);
	radian += Math.atan2(x - centerX, centerY - y);
	if (radian < -(Math.PI / 2)) {
		radian += Math.PI * 2;
	}
	
	return radian;
}


//--------------------------------------------------------------//
//			Count Down
//--------------------------------------------------------------//

function isCountingDown()
{
	return (_countDownTimer != null);
}


function startCountingDown()
{
	var count = null;
	var clock = null;
	
	// Convert count down timer to visible/invisible version
	if (_countDownTimer) {
		// Record count for later use
		count = getCount();
		
		// Record clock for later use
		clock = new Date(widget.preferenceForKey(MinutesClockKey));
		
		// Clear old count down timer
		clearInterval(_countDownTimer);
		delete _countDownTimer;
		_countDownTimer = null;
	}
	// Start resetted count down
	else {
		// Calc new clock
		clock = new Date();
		clock.setMilliseconds(0);
		clock.setSeconds(clock.getSeconds() + getTime());
		widget.setPreferenceForKey(clock.toString(), MinutesClockKey);
		updateClock();
	}
	
	// Start invisible version count down
	if (!_isVisible) {
		_countDownTimer = setInterval("countDown()", count * 1000);
		return;
	}
	
	// Start visible version count down
	_countDownTimer = setInterval("countDown()", 1000);
	if (clock.getTime() <= (new Date()).getTime()) {
		// Stop immediately
		countDown();
		return;
	}
	
	if (!isResetting()) {
		// Initialize time texts
		updateTimeRelatedUIs();
		
		// Fade-in timeSub text field if needed
		if (getCount() > 60) {
			startTimeSubFadeAnimation(1, 2);
		}
		else {
			startTimeSubFadeAnimation(0, 2);
		}
	}
	
	// Start flicker animation
	startFlickerAnimation(1.0)
	
	// Stop update clock timer
	stopUpdateClockTimer();
	
	// Cue fadeOutTimer
	startFadeOutCueTimerOrCue();
}


function countDown()
{
	// Filter
	if (isResetting()) {
		return;
	}
	
	// Update time related UIs
	updateTimeRelatedUIs();
	
	// Get count
	var count;
	count = getCount();
	if (count <= 0) {
		stopCountingDown();
		return;
	}
	if (count <= 60) {
		// Fade out timeSub
		if (!isTimeSubFadingOut() && document.getElementById("timeSub").style.opacity != 0) {
			startTimeSubFadeAnimation(0, 1);
		}
	}
}


function stopCountingDown()
{
	// Filter
	if (!_countDownTimer) {
		return;
	}
	
	// Get count
	var count;
	count = getCount();
	
	// Stop count down timer
	clearInterval(_countDownTimer);
	delete _countDownTimer;
	_countDownTimer = null;
	
	// Stop fadeOutCueTime and fadeOutTimer
	stopFadeOutCueTimer();
	stopFadeOutTimer();
	
	// Check completeness
	var isCompleted;
	isCompleted = (count <= 0);
	if (!isCompleted) {
		// Finish flicker animation
		finishFlickerAnimation();
		
		// Fade out time sub
		startTimeSubFadeAnimation(0, 2);
		
		// Start update clock timer
		startUpdateClockTimer();
		
		return;
	}
	
	// Completed...
	var repeat = false;
	var sleep = false;
	
	// Do action
	var action;
	action = getAction();
	switch (action) {
	// Play iTunes
	case MinutesPlayITunesAction: {
		playITunes();
		repeat = getAddon();
		break;
	}
	// Stop iTunes
	case MinutesStopITunesAction: {
		stopITunes();
		sleep = getAddon();
		break;
	}
	// Beep
	case MinutesBeepAction: {
		beep();
		repeat = getAddon();
		break;
	}
	// Open File
	case MinutesOpenFileAction: {
		openFile();
		repeat = getAddon();
		break;
	}
	}
	
	// Repeat
	if (repeat) {
		if (_isVisible) {
			// Start reset niamation
			startResetAnimation(parseFloat(0));
		}
		else {
			// Cue fadeOutTimer
			startFadeOutCueTimerOrCue();
		}
		
		// Start counting down again
		startCountingDown();
	}
	// Stop and Revert
	else {
		if (_isVisible) {
			startResetAnimation(parseFloat(0));
			finishFlickerAnimation();
			startUpdateClockTimer();
		}
	}
	
	// Sleep
	if (sleep && Minutes) {
		Minutes.sleep();
	}
	// Show message
	else if (Minutes) {
		showMessage(getLocalizedString("It's about time!"));
//	var message;
//	var minutes;
//	minutes = parseInt(Math.floor(getTime() / 60));
//	if (minutes == 1) {
//		message = getLocalizedString("1 minute passed.");
//	}
//	else {
//		message = getStringWithFormat(getLocalizedString("%@ minutes passed."), minutes + "");
//	}
//	showMessage(message);
	}
}


//--------------------------------------------------------------//
//		iTuens Fade Out Timer
//--------------------------------------------------------------//

function startFadeOutCueTimerOrCue()
{
	// Filter
	if (!isCountingDown() || _fadeOutTimer || _fadeOutCueTimer) {
		return;
	}
	
	// Get interval
	var interval;
	interval = getCount() * 1000;
	
	// Start fadeOutCueTimer
	if (interval > _fadeOutDuration) {
		_fadeOutCueTimer = setInterval("startFadeOutTimer()", interval - _fadeOutDuration);
	}
	// Cue immediately
	else {
		startFadeOutTimer();
	}
}


function stopFadeOutCueTimer()
{
	if (_fadeOutCueTimer) {
		clearInterval(_fadeOutCueTimer);
		delete _fadeOutCueTimer;
		_fadeOutCueTimer = null;
	}
}


function startFadeOutTimer()
{
	// stop fadeOutCueTimer
	stopFadeOutCueTimer();
	
	// Start fadeOutTimer
	if (!_fadeOutTimer && Minutes) {
		// Start timer
		_fadeOutTimer = setInterval("fadeOutTimerFired();", 500);
	}
}


function fadeOutTimerFired()
{
	// Filter
	if (!isCountingDown()
		|| getAction() != MinutesStopITunesAction 
		|| !getFade()
		|| !Minutes
		|| !Minutes.isITunesLaunched())
	{
		return;
	}
	
	// Calc interval
	var interval;
	interval = getCount() * 1000;
	
	// Recorde original volume if it isn't set yet
	if (_originalVolume == -1) {
		_originalVolume = Minutes.volume();
	}
	
	// Calc volume
	var volume;
	volume = Math.ceil(_originalVolume * (interval / _fadeOutDuration));
	Minutes.setVolume(volume);
}

function stopFadeOutTimer()
{
	// Stop fadeOutTimer
	if (_fadeOutTimer) {
		// Stop timer
		clearInterval(_fadeOutTimer);
		delete _fadeOutTimer;
		_fadeOutTimer = null;
	}
}

//--------------------------------------------------------------//
//		Flicker Animation
//--------------------------------------------------------------//

function startFlickerAnimation(targetOpacity)
{
	// Clean up flicker animator
	if (_flickerAnimator) {
		_flickerAnimator.stop();
		delete _flickerAnimator;
		_flickerAnimator = null;
	}
	
	// Start animation
	var currentOpacity;
	var duration;
	currentOpacity = document.getElementById("displayBackProgressImg").style.opacity;
	if (currentOpacity + "" == "") {
		currentOpacity = 0;
	}
	duration = _flickerDuration * Math.abs(targetOpacity - currentOpacity);
	_flickerAnimator = new AppleAnimator(duration, 30, parseFloat(currentOpacity), parseFloat(targetOpacity), flickerAnimatorFired);
	_flickerAnimator.oncomplete = flickerAnimatorCompleted;
	_flickerAnimator.start();
}


function flickerAnimatorFired(animator, current, start, finish)
{
	// Set opacity
	document.getElementById("displayBackProgressImg").style.opacity = current;
}


function flickerAnimatorCompleted()
{
	if (isCountingDown()) {
		// Repeat animation
		var currentOpacity, targetOpacity;
		currentOpacity = document.getElementById("displayBackProgressImg").style.opacity;
		targetOpacity = (currentOpacity < 0.5) ? 1.0 : 0.0;
		startFlickerAnimation(targetOpacity);
	}
	else {
		// Delete flicker animator
		delete _flickerAnimator;
		_flickerAnimator = null;
	}
}


function finishFlickerAnimation()
{
	if (!_flickerAnimator) {
		return;
	}
	
	startFlickerAnimation(0);
}


//--------------------------------------------------------------//
//		timeSub Fade Animation
//--------------------------------------------------------------//

function isTimeSubFadingOut()
{
	return (_timeSubFadeAnimator && _timeSubFadeAnimator.animations[0].to == 0);
}


function startTimeSubFadeAnimation(targetOpacity, speed)
{
	// Clean up fade animator
	if (_timeSubFadeAnimator) {
		_timeSubFadeAnimator.stop();
		delete _timeSubFadeAnimator;
		_timeSubFadeAnimator = null;
	}
	
	// Start animation
	var currentOpacity;
	var duration;
	currentOpacity = document.getElementById("timeSub").style.opacity;
	if (currentOpacity + "" == "") {
		currentOpacity = 0;
	}
	duration = _timeSubDefaultFadeDuration * Math.abs(targetOpacity - currentOpacity);
	duration /= speed;
	_timeSubFadeAnimator = new AppleAnimator(duration, 30, parseFloat(currentOpacity), parseFloat(targetOpacity), timeSubFadeAnimatorFired);
	_timeSubFadeAnimator.oncomplete = timeSubFadeAnimatorCompleted;
	_timeSubFadeAnimator.start();
}


function timeSubFadeAnimatorFired(animator, current, start, finish)
{
	// Set opacity
	document.getElementById("timeSub").style.opacity = current;
}


function timeSubFadeAnimatorCompleted()
{
	// Delete time sub fade animator
	delete _timeSubFadeAnimator;
	_timeSubFadeAnimator = null;
}


//--------------------------------------------------------------//
//		Update clock timer
//--------------------------------------------------------------//

function startUpdateClockTimer()
{
	if (!_updateClockTimer || _isVisible) {
		_updateClockTimer = setInterval("updateClock()", 1000);
	}
}


function stopUpdateClockTimer()
{
	if (_updateClockTimer) {
		clearInterval(_updateClockTimer);
		delete _updateClockTimer;
		_updateClockTimer = null;
	}
}


function isResetting()
{
	return (_resetAnimator);
}


function startResetAnimation(startCount)
{
	// Filter
	if (_resetAnimator) {
		return;
	}
	
	// Record start count
	_resetStartingSeconds = startCount;
	
	// Start animation
	_resetAnimator = new AppleAnimator(1000, 10, parseFloat(0), parseFloat(1), resetAnimatorFired);
	_resetAnimator.oncomplete = resetAnimatorCompleted;
	_resetAnimator.start();
}


function resetAnimatorFired(animator, current, start, finish)
{
	var seconds;
	var opacity;
	var ratio;
	var timeMain, timeSub;
	timeMain = document.getElementById("timeMain");
	timeSub = document.getElementById("timeSub");
	
	// First half
	if (current < 0.5) {
		// Calc fade out ratio
		ratio = current / 0.5;
		
		// Set opacity of timeMain
		opacity = timeMain.style.opacity;
		if (opacity + "" == "") {
			opacity = 1.0;
		}
		opacity = opacity * (1.0 - ratio);
		if (opacity < 0.00001) {opacity = 0;}		// I don't know, but this line is needed in Tiger
		timeMain.style.opacity = opacity;
		
		// Set opacity of timeSub
		opacity = timeSub.style.opacity;
		if (opacity + "" == "") {
			opacity = 0;
		}
		opacity = opacity * (1.0 - ratio);
		if (opacity < 0.00001) {opacity = 0;}		// I don't know, but this line is needed in Tiger
		timeSub.style.opacity = opacity;
		
		// Calc seconds for later use
		seconds = _resetStartingSeconds + (getCount() - _resetStartingSeconds) * ratio;
	}
	// Second half
	else {
		// Set time texts
		updateTimeText();
		
		// Calc fade in ratio and opacity
		ratio = (current - 0.5) * 2.0;
		opacity = ratio;
		
		// Set opacity of timeMain
		timeMain.style.opacity = opacity;
		if (isCountingDown() && getCount() > 60) {
			timeSub.style.opacity = opacity;
		}
		
		// Calc seconds for later use
		seconds = getCount();
	}
	
	// Animate knob and progress image
	drawProgressImage(seconds);
	drawKnobImage(seconds);
	moveKnobControlRegion(seconds);
}


function resetAnimatorCompleted()
{
	// Assume knob and progress image
	var count;
	count = getCount();
	drawProgressImage(count);
	drawKnobImage(count);
	moveKnobControlRegion(count);
	
	// Clean up timer
	if (_resetAnimator) {
		_resetAnimator.stop();
		delete _resetAnimator;
		_resetAnimator = null;
	}
}


//--------------------------------------------------------------//
//		Actions
//--------------------------------------------------------------//

function showBack(event)
{
	// Update back UI
	var action;
	action = getAction();
	switch (action) {
	case MinutesPlayITunesAction: {
		updatePlaylists();
		break;
	}
	case MinutesStopITunesAction: {
		break;
	}
	case MinutesBeepAction: {
		break;
	}
	case MinutesOpenFileAction: {
		if (Minutes) {
			Minutes.updateOpenFile();
		}
		break;
	}
	}
	
	// Start flip animation
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	if (window.widget) {
		widget.prepareForTransition("ToBack");
	}
	front.style.visibility = "hidden";
	back.style.display = "block";
	if (window.widget) {
		setTimeout('widget.performTransition();', 0);
	}
}

function showFront(event)
{
	// Start flip animation
	var front = document.getElementById("front");
	var back = document.getElementById("back");
	if (window.widget) {
		widget.prepareForTransition("ToFront");
	}
	front.style.visibility = "visible";
	back.style.display="none";
	if (window.widget) {
		setTimeout('widget.performTransition();', 0);
	}
}

if (window.widget) {
	widget.onremove = remove;
	widget.onhide = hide;
	widget.onshow = show;
	widget.onsync = sync;
}

function knobDowned(event)
{
	// Filter
	if (isResetting()) {
		return;
	}
	
	// Stop counting down
	stopCountingDown();
	
	// Update time immediately
	knobDragged(event);
	
	// Add event listener for dragging
	document.addEventListener("mousemove", knobDragged);
	document.addEventListener("mouseup", knobUpped);
}


function knobDragged(event)
{
	// Calc nearest radian
	var nearestRadian;
	var radian, timeRadian;
	var hour = 3600;
	timeRadian = getRadianOfSeconds(getTime());
	nearestRadian = radian = getFirstRadianForPoint(event.clientX, event.clientY) - Math.PI * 2;
	do {
		radian += Math.PI * 2;
		if (Math.abs(radian - timeRadian) < Math.abs(nearestRadian - timeRadian)) {
			nearestRadian = radian;
		}
	} while (radian < timeRadian);
	
	// Set time
	setTime(getSecondsOfRadian(nearestRadian));
	updateTimeRelatedUIs();
}


function knobUpped(event)
{
	// Remove event listener for dragging
	document.removeEventListener("mousemove", knobDragged);
	document.removeEventListener("mouseup", knobUpped);
	
	// Refine time
	setTime(getTime() - (getTime() % 60));
	updateTimeRelatedUIs();
	
	// Start counting down
	startCountingDown();
}


function displayClicked(event)
{
	// Filter
	if (isResetting()) {
		return;
	}
	
	// Check whether it was really clicked
	var x, y, radius;
	var display, displayOrigin;
	display = document.getElementById("displayControlRegion");
	displayOrigin = getElementPosition(display);
	x = event.clientX - displayOrigin[0];
	y = event.clientY - displayOrigin[1];
	radius = Math.sqrt(Math.pow(x - display.width / 2, 2) + Math.pow(y - display.height / 2, 2));
	if (radius > Math.min(display.width, display.height) / 2) {
		return;
	}
	
	if (isCountingDown()) {
		// Revert to user setting
		startResetAnimation(getCount());
		
		// Stop count down
		stopCountingDown();
	}
	else {
		startCountingDown();
	}
}


function actionChanged(event)
{
	var action;
	action = (getAction() + 1) % MinutesNumberOfActions;
	setAction(action);
}


function addonChanged(event)
{
	var addon;
	addon = getAddon() ? 0 : 1;
	setAddon(addon);
}


function skinChanged(event)
{
	// Get new skin
	var skin;
	var sender;
	sender = event.target;
	skin = sender.id.replace("ButtonImg", "");
	
	// Set new skin
	setSkin(skin);
}


function beepChanged(event)
{
	// Get beep pop up
	var popup;
	popup = document.getElementById("beepPopUp");
	
	// Get beep url
	var url;
	url = popup.options[popup.selectedIndex].value;
	
	// Set beep
	setBeep(url, false, true);
}


function playlistChanged(event)
{
	var popup;
	var playlist, kind;
	popup = document.getElementById("playlistPopUp");
	playlist = popup.options[popup.selectedIndex].innerText;
	kind = popup.options[popup.selectedIndex].value;
	widget.setPreferenceForKey(playlist, MinutesPlaylistKey);
	widget.setPreferenceForKey(kind, MinutesPlaylistKindKey);
}


function fadeChanged(event)
{
	var fade;
	fade = document.getElementById("fadeCheckboxButton").checked;
	setFade(fade ? 1 : 0, false);
}


function openFileDragEnter(event)
{
	openFileDragOver(event);
}

function openFileDragOver(event)
{
	// Filter
	if (!Minutes) {
		return;
	}
	
	// Get openFileControlRegion
	var controlRegion;
	controlRegion = document.getElementById("openFileControlRegion");
	
	// Get clipboard
	var clipboard;
	clipboard = event.dataTransfer;
	
	// Check type
	var containsURI = false;
	var types;
	types = clipboard.types;
	for (var i = 0; i < types.length; i++) {
		if (types[i] == "text/uri-list") {
			containsURI = true;
			break;
		}
	}
	if (!containsURI) {
		return;
	}
	
	// Set effect
	var effect;
	effect = clipboard.effectAllowed;
	if (effect == "all" || effect == "link" || effect == "copyLink" || effect == "linkMove") {
		clipboard.dropEffect = "link";
	}
	else {
		clipboard.dropEffect = "none";
		return;
	}
	
	// Notify that I'll handle the event
	event.stopPropagation();
	event.preventDefault();
}


function openFileDrop(event)
{
	// Get clipboard
	var clipboard;
	clipboard = event.dataTransfer;
	
	// Get first uri
	var uri, uris;
	uris = clipboard.getData("text/uri-list").split("\n");
	uri = uris[0];
	
	// Set open file
	if (Minutes) {
		Minutes.setOpenFile(uri);
	}
	
	event.stopPropagation();
	event.preventDefault();
}


//--------------------------------------------------------------//
//		Drawing
//--------------------------------------------------------------//

function updateTimeRelatedUIs()
{
	var count;
	count = getCount();
	
	updateTimeText();
	updateClock();
	drawProgressImage(count);
	drawKnobImage(count);
	moveKnobControlRegion(count);
}


function updateTimeText()
{
	// Get count
	var count;
	if (isCountingDown) {
		count = Math.max(getCount(), 0);
	}
	else {
		count = getTime();
	}
	
	// Calc minutes and seconds
	var minutes, seconds;
	minutes = Math.floor(count / 60);
	seconds = count % 60;
	
	// Display minutes and seconds
	var main, sub;
	main = document.getElementById("timeMain");
	sub = document.getElementById("timeSub");
	if (minutes > 0) {
		main.innerText = minutes + "'";
		if (isCountingDown()) {
			sub.innerText = seconds + '"';
		}
	}
	else {
		main.innerText = seconds + '"';
	}
}


function updateClock()
{
	// Get a time for clock
	var clockTime;
	if (isCountingDown()) {
		// Get clock time from preference
		clockTime = new Date(widget.preferenceForKey(MinutesClockKey));
	}
	else {
		// Calc clock time using time setting
		clockTime = new Date();
		clockTime.setSeconds(clockTime.getSeconds() + (getTime() - getTime() % 60));
	}
	
	// Get hours and minutes
	var hours, minutes;
	hours = clockTime.getHours();
	minutes = clockTime.getMinutes();
	
	// Update UI
	var minutesStr;
	if (minutes < 10) {
		minutesStr = "0" + minutes;
	}
	else {
		minutesStr = "" + minutes;
	}
	document.getElementById("clock").innerText = hours + ":" + minutesStr;
}


function moveKnobControlRegion(seconds)
{
	// Get parameter
	var context;
	var knob;
	var knobW, knobH;
	knob = document.getElementById("knobControlRegion");
	knobW = knob.width;
	knobH = knob.height;
	context = knob.getContext("2d");
	
	// Clear context
	context.clearRect(0, 0, knobW, knobH);
	
	// Move knob
	var centerX, centerY;
	var knobCenterX, knobCenterY;
	var radius;
	var radian;
	var display, displayPosition;
	display = document.getElementById("displayControlRegion");
	displayPosition = getElementPosition(display);
	centerX = displayPosition[0] + display.width / 2;
	centerY = displayPosition[1] + display.height / 2;
	radius = display.height / 2 + knobH / 3;
	radian = getRadianOfSeconds(seconds);
	knobCenterX = centerX + Math.cos(radian) * radius;
	knobCenterY = centerY + Math.sin(radian) * radius;
	setElementPosition(knob, knobCenterX - knobW / 2, knobCenterY - knobH / 2);
	
	// Draw control region
	if (KNOB_TEST) {
		context.save();
		{
			context.fillStyle = "rgba(0, 0, 1, 0.5)";
			context.beginPath();
			context.arc(knobW / 2, knobH / 2, knobW / 2, 0, Math.PI * 2, false);
			context.fill();
		}
		context.restore();
	}
}


function drawProgressImage(seconds)
{
	// Check whether image was loaded
	if (!_progressImage.complete) {
		setTimeout("drawProgressImage(" + seconds + ")", 100);
		return;
	}
	
	// Get canvas context and its info
	var context;
	var width, height;
	var canvas;
	canvas = document.getElementById("progressCanvas");
	context = canvas.getContext("2d");
	width = canvas.width;
	height = canvas.height;
	
	// Drawing
	context.clearRect(0, 0, width, height);
	context.save();
	{
		context.translate(width / 2, height / 2);
		
		// Set clipping path
		var hour = 3600;
		if (seconds < hour) {
			var radius;
			radius = Math.min(width, height) / 2;
			context.beginPath();
			context.moveTo(0, 0);
			context.arc(0, 0, radius, getRadianOfSeconds(0), getRadianOfSeconds(seconds), false);
			context.closePath();
			context.clip();
		}
		
		// Draw progress image
		context.translate(-(width / 2), -(height / 2));
		context.drawImage(_progressImage, 0, 0);
	}
	context.restore();
}


function drawKnobImage(seconds)
{
	// Check whether image was loaded
	if (!_knobImage.complete) {
		setTimeout("drawKnobImage(" + seconds + ")", 100);
		return;
	}
	
	// Get canvas context and its info
	var context;
	var width, height;
	var canvas;
	canvas = document.getElementById("knobCanvas");
	context = canvas.getContext("2d");
	width = canvas.width;
	height = canvas.height;
	
	// Calc image dimensions
	var imgW, imgH;
	var scaleFactor;
	imgW = _knobImage.width;
	imgH = _knobImage.height;
	if (imgW > width || imgH > height) {
		scaleFactor = Math.min(width / imgW, height / imgH);
		imgW *= scaleFactor;
		imgH *= scaleFactor;
	}
	
	// Calc angle
	var angle;
	angle = getRadianOfSeconds(seconds) + Math.PI / 2;
	
	// Drawing
	context.clearRect(0, 0, width, height);
	context.save();
	{
		context.translate(width / 2, height / 2);
		context.rotate(angle);
		context.drawImage(_knobImage, -(imgW / 2), -(imgH / 2), imgW, imgH);
	}
	context.restore();
}


function updatePlaylists()
{
	// Get playlist popup
	var popup;
	popup = document.getElementById("playlistPopUp");
	
	// Get prefered playlist and kind
	var prefPlaylist, prefKind;
	prefPlaylist = widget.preferenceForKey(MinutesPlaylistKey);
	prefKind = widget.preferenceForKey(MinutesPlaylistKindKey);
	
	// Update popup options
	if (Minutes) {
		var html = "";
		
		// Update playlists in plug-in
		Minutes.updatePlaylists();
		
		// Get playlists
		var playlists, playlistKinds;
		playlists = Minutes.playlists();
		playlistKinds = Minutes.playlistKinds();
		for (var i = 0; i < playlists.length; i++) {
			var playlist, kind;
			playlist = playlists[i];
			kind = playlistKinds[i];
			
			// Add option
			if ((!prefKind && kind == "Music")
				|| (prefKind && prefKind != "none" && prefKind == kind)
				|| (prefKind == kind && prefPlaylist == playlist))
			{
				html += "<option value=\"" + kind + "\" selected=\"selected\">" + playlist + "</option>";
			}
			else {
				html += "<option value=\"" + kind + "\">" + playlist + "</option>";
			}
		}
		popup.innerHTML = html;
		
		// Update preference
		if (popup.selectedIndex == -1) {
			popup.selectedIndex = 0;
		}
		widget.setPreferenceForKey(popup.options[popup.selectedIndex].innerText, MinutesPlaylistKey);
		widget.setPreferenceForKey(popup.options[popup.selectedIndex].value, MinutesPlaylistKindKey);
	}
	else {
		popup.innerHTML = "<option value=\"\">No iTunes</option>";
	}
}


// Called by plug-in
function updateOpenFile()
{
	// Get filename and icon name
	var filename, iconName;
	filename = widget.preferenceForKey(MinutesOpenFileNameKey);
	iconName = widget.preferenceForKey(MinutesOpenFileIconNameKey);
	
	// Determine icon image source and message
	var imgSrc, message;
	if (filename && filename.length) {
		message = filename;
		if (iconName && iconName.length) {
			imgSrc = getInstanceApplicationSupportDirectoryURL() + "/OpenFile/" + iconName;
		}
		else {
			imgSrc = "Images/actionOpenfile.png";
		}
	}
	else {
		message = "drop file here";
		imgSrc = "Images/backDropIcon.png";
	}
	document.getElementById("fileImg").src = imgSrc;
	document.getElementById("fileTextLabel").innerText = message;
}

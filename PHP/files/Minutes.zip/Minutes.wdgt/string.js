/*
 string.js
 
 Author: MIURA Kazki
 
 Copyright 2008 Nitram+Nunca. All rights reserved.
*/


function getStringWithFormat(formatString)
{
	var string;
	var args;
	string = formatString;
	args = getStringWithFormat.arguments;
	
	for (var i = 1; i <= args.length; i++) {
		var find;
		find = "%" + i + "$@";
		string = string.replace(find, args[i]);
	}
	
	return string;
}
